import flet as ft
import asyncio
import os
import random
from views.escape import escape_view
from views.extinguish import extinguish_view
from views.quiz import quiz_view
from views.tools import tools_view

async def main(page: ft.Page):
    page.title = "火災安全衛士 Pro"
    page.window_width = 450
    page.window_height = 1000
    page.padding = 0

    # 初始化資料狀態
    state = {
        "raw_pool": [],
        "quiz": {"score": 0, "current_q": 0, "session_questions": []},
        "is_loading": True 
    }

    async def load_questions():
        # 直接將題庫內容內置，解決所有網路讀取失敗問題
        raw_text = """油鍋起火時，最不該使用的是？|水|滅火毯|鍋蓋|乾粉
插座冒煙起火，應優先使用哪種滅火器？|二氧化碳|泡沫|水輪|濕毛巾
發生火災時，應採取什麼姿勢逃生？|爬行低姿勢|直立快跑|跳窗|原地大叫
二氧化碳滅火器的標籤是什麼顏色？|黑色|藍色|黃色|紅色
泡沫滅火器絕對不能用於哪種火災？|電器|木材|汽油|紙張
乾粉滅火器的標籤顏色是？|藍色|紅色|奶油色|黑色
逃生時若門把發燙，應該？|不可開門|強行開門|用手撞門|潑水冷卻
火災逃生口訣「PASS」中，第一個P是？|Pull (拔保險)|Push (推)|Panic (驚慌)|Press (按)
人身上起火時應採取什麼動作？|停、躺、滾|快速奔跑|跳入水池|脫掉衣服
消防喉最適合用於什麼材質起火？|木材/紙張|油鍋|電器插座|金屬
火災中致死率最高的是？|濃煙嗆傷|高溫燒傷|跳樓受傷|物體壓傷
滅火器上的壓力表，指針在什麼顏色代表正常？|綠色|紅色|黃色|黑色
發現火災第一件事應該？|大聲呼叫告知他人|自己先滅火|收拾財物|拍照上傳
高樓火災時，絕對不能搭乘？|電梯|樓梯|逃生梯|雲梯車
家庭油鍋起火，蓋上鍋蓋後應？|關閉瓦斯電源|立刻打開鍋蓋|加水降溫|搬動油鍋
身上衣服著火，用手遮住臉部是為了？|保護呼吸道|防止毀容|比較美觀|視線較好
下列何者不是滅火三要素？|二氧化碳|可燃物|助燃物|熱源
發現門縫有煙進來，應？|用濕布塞住縫隙|趕快開門逃生|打開窗戶通風|在房間跳動
使用滅火器應站在火源的？|上風處|下風處|正上方|隨便哪裡
消防報警電話是？|999/119|110|112|123
延長線過載使用會導致？|電線發熱起火|省電|增加網速|電壓變穩
家中除濕機若要長時間開啟，應注意？|濾網清潔與水箱滿水自動停止|放在衣櫥內|蓋上毛巾防塵|貼著牆壁放
使用瓦斯爐火顏色應為什麼色較安全？|藍色|紅色|黃色|白色
浴室內的插座應安裝？|漏電斷路器|延長線|電壓計|保險絲
聞到強烈瓦斯味時，第一步不可？|開啟抽油煙機|關閉瓦斯總閥|輕輕開啟窗戶|跑到戶外報警
神明桌祭拜最容易因什麼起火？|香爐灰掉落或電燈線路老舊|水果太多|木頭太乾|空氣不流通
清洗排油煙機是為了防止？|油垢遇火引起煙囪效應|變髒|省電|煮飯不好吃
電氣火災屬於哪一類火災？|C類|A類|B類|D類
鋰電池充電時應避免？|放在易燃物上方充電|在陰涼處充電|使用原廠充電器|充飽後移除
家中發生小火災且無法撲滅時，應？|立即關門逃生|躲進浴室|收拾珠寶|打開大門通風
住宅用火災警報器應裝在哪？|天花板|地板上|桌子下|牆角邊
防火門的正確狀態應該是？|常時關閉|常時開啟|半開半關|上鎖
睡覺時發生火災，誰最能救你一命？|住宅用火災警報器|鄰居大叫|鬧鐘|寵物
高樓層逃生時應優先選擇？|安全樓梯|貨梯|景觀電梯|跳窗
身上著火卻無法躺下滾動時應？|用厚外套覆蓋熄滅|快速奔跑|對著風吹|用手拍打
乾粉滅火器噴出的是？|白色粉末|水霧|藍色液體|黑色氣體
火場逃生時，門把發燙表示？|門後已有高溫火煙|門被太陽曬熱|門故障|沒事可以開
普通木材火災屬於？|A類火災|B類火災|C類火災|D類火災
酒精燈起火應如何處置？|用濕布或蓋子蓋住|用力吹熄|用手扇熄|用水澆滅
樓梯間堆放雜物會？|妨礙逃生並助長火勢|顯得生活豐富|方便取物|節省空間
滅火器壓力表指針在紅色區域代表？|壓力不足|壓力正常|壓力太強|快爆炸了
火災發生後，應撥打？|999|110|112|123
火災報警時應告知？|詳細地址與起火物|今天的日期|自己的學歷|晚餐吃什麼
公共場所逃生路徑應標示為？|綠底白字出口燈|紅底黑字|黃色警示帶|藍色箭頭
商場火災逃生時，應隨身？|什麼都不要拿|拿走筆電|帶走剛買的衣服|拿著滅火器逃生
火場中如果被煙困住，應尋找？|相對安全處關門求援|通風良好的陽台跳下|躲入衣櫥|躲入浴缸
二氧化碳滅火器主要滅火原理是？|窒息法與冷卻法|化學連鎖反應|物理衝擊|水淹法
油類火災（B類）不可用什麼滅？|水|乾粉|泡沫|二氧化碳
金屬火災屬於哪一類？|D類|A類|C類|K類
室內消防栓的使用步驟第一步是？|按鈴報警|開閥|拉水帶|拿瞄子
防煙面罩的主要功能是？|濾除有害煙氣與熱氣|提供氧氣|防曬|防塵
火場低姿勢逃生，頭部應距離地面？|15至60公分|1公尺|10公分以下|靠在牆上
山林火災發生時應往哪跑？|側風或逆風處|順風處|山頂|濃煙處
公共場所的自動灑水系統是由什麼啟動？|溫度達到設定值|手動按鈕|煙霧傳感器|定時器
加油站內嚴禁煙火是因為？|汽油揮發物易爆|會變黑|很臭|浪費油
滅火器檢驗合格標籤通常效期為？|1至3年|10年|永久有效|一個月
家中煮飯人離開應？|人離火熄|把火開小|找小孩顧|人離火開
逃生時如果衣服著火，絕對不可？|奔跑|躺下|遮臉|滾動
K類火災是指什麼起火？|廚房動植物油|木材|金屬|電線
滅火器的「S」Sweep 是指？|左右掃射|停止|跳動|拔開
濃煙流動的速度比人跑的速度？|快很多|慢一點|一樣快|煙不會動
火場中「煙囪效應」最常發生在？|垂直樓梯間|地下室|戶外平地|臥室
下列何者是助燃物？|氧氣|二氧化碳|氮氣|石棉
電線老舊發生火災，原因通常是？|短路或過載|線太長|顏色不對|電壓太低
滅火器使用時的距離應保持約？|2至3公尺|10公尺|0.5公尺|越高越好
發現森林火災應撥打？|999/119|100|114|105
地震發生時，若正在瓦斯爐旁應？|關閉瓦斯並就地避難|直接跑出去|先拍照|躲進冰箱
火場逃生原則是？|向下逃生，無法則水平避難|往頂樓跑|躲廁所|躲櫃子
公共場所的防火捲門下方？|不可堆放雜物|可以停車|適合擺貨架|可以坐著休息
防煙門上貼有「常關式防火門」，應？|保持關閉不鎖死|用重物頂住保持開啟|隨時鎖上鎖頭|拆掉門板
火災中常見的一氧化碳中毒是因為？|一氧化碳會搶走血紅素氧氣|它太臭了|它會爆炸|它會讓眼睛瞎掉
住宅用火警探測器電池沒電會？|發出間隔的嗶聲提醒|自動關機|爆炸|冒煙
室內裝修應優先選用？|耐燃材料|純木頭|塑膠板|泡棉壁貼
發生火災被困在浴室危險是因為？|塑膠門易熔化且無法阻擋濃煙|水不夠多|沒有窗戶|太冷了
火災現場濃煙密布，應？|沿牆壁尋找出口|往中央跑|深呼吸|閉上眼快跑
醫院火災逃生，對於行動不便者應優先？|水平移位至避難區|揹下樓梯|坐電梯|留在原處不理
家裡滅火器應放在？|門口或廚房明顯處|儲藏室深處|閣樓|床底下
火場逃生「三不」不包含？|不可呼吸|不可搭電梯|不可躲浴室|不可折返
滅火器指針到黃色區代表？|壓力略高（仍可使用）|壞了|沒粉了|快過期
火災報警時，若不知地址應？|描述明顯目標或電線桿編號|掛掉電話|大哭|自己走去消防局"""

        parsed_data = []
        for line in raw_text.splitlines():
            clean_line = line.strip()
            if not clean_line or "|" not in clean_line:
                continue
            parts = clean_line.split("|")
            if len(parts) >= 2:
                parsed_data.append({
                    "q": parts[0],
                    "a": [p.strip() for p in parts[1:] if p.strip()],
                    "correct_text": parts[1].strip()
                })
        
        # 更新狀態
        if parsed_data:
            state["raw_pool"] = parsed_data
        
        state["is_loading"] = False
        reset_quiz()
        render_page()

    def reset_quiz():
        state["quiz"]["score"] = 0
        state["quiz"]["current_q"] = 0
        state["quiz"].pop("current_options", None) 
        
        if state["raw_pool"]:
            sample_size = min(len(state["raw_pool"]), 10)
            state["quiz"]["session_questions"] = random.sample(state["raw_pool"], sample_size)
        else:
            state["quiz"]["session_questions"] = []

    def check_answer(only_update_ui=False):
        if not only_update_ui:
            state["quiz"]["current_q"] += 1
            state["quiz"].pop("current_options", None) 
        render_page()

    def render_page(e=None):
        page.controls.clear()
        idx = nav_bar.selected_index
        titles = ["首頁", "逃生", "滅火", "測驗", "工具"]
        
        page.appbar = ft.AppBar(
            title=ft.Text(titles[idx], weight="bold", color="white"),
            bgcolor="#E63946",
            actions=[ft.IconButton(ft.Icons.HOME, icon_color="white", on_click=lambda _: change_tab(0))]
        )

        if idx == 0:
            page.add(ft.Column([
                ft.Container(
                    height=180, padding=30, 
                    gradient=ft.LinearGradient(colors=["#E63946", "#D62828"]),
                    content=ft.Column([
                        ft.Text("安全教育 Pro", color="white", size=28, weight="bold"), 
                        ft.Text("具體化防災手冊", color="white", size=16)
                    ])
                ),
                ft.Container(
                    padding=20, 
                    content=ft.Column([
                        ft.ListTile(leading=ft.Icon(ft.Icons.RUN_CIRCLE, color="orange"), title=ft.Text("逃生指引"), on_click=lambda _: change_tab(1)),
                        ft.ListTile(leading=ft.Icon(ft.Icons.FIRE_EXTINGUISHER, color="green"), title=ft.Text("滅火教學"), on_click=lambda _: change_tab(2)),
                        ft.ListTile(leading=ft.Icon(ft.Icons.QUIZ, color="blue"), title=ft.Text("小測驗挑戰"), on_click=lambda _: change_tab(3)),
                        ft.ListTile(leading=ft.Icon(ft.Icons.BUILD, color="grey"), title=ft.Text("救生工具箱"), on_click=lambda _: change_tab(4)),
                        ft.Divider(height=20),
                        ft.FilledButton("緊急求助 999", icon=ft.Icons.PHONE, bgcolor="red", on_click=lambda _: page.launch_url("tel:999"), width=400, height=60),
                    ], spacing=10)
                )
            ], scroll=ft.ScrollMode.AUTO))
        elif idx == 1: page.add(escape_view())
        elif idx == 2: page.add(extinguish_view())
        elif idx == 3: 
            if state["is_loading"]:
                page.add(
                    ft.Container(
                        expand=True,
                        content=ft.Column([
                            ft.ProgressRing(),
                            ft.Text("題庫載入中...")
                        ], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER)
                    )
                )
            elif not state["quiz"]["session_questions"]:
                reset_quiz()
                render_page()
            else:
                page.add(quiz_view(state["quiz"], check_answer, lambda _: (reset_quiz(), render_page())))
        
        elif idx == 4: page.add(tools_view(page))
        page.update()

    def change_tab(index):
        nav_bar.selected_index = index
        if index == 3: 
            if not state["is_loading"]:
                reset_quiz()
        render_page()

    nav_bar = ft.NavigationBar(
        destinations=[
            ft.NavigationBarDestination(icon=ft.Icons.HOME, label="首頁"),
            ft.NavigationBarDestination(icon=ft.Icons.RUN_CIRCLE, label="逃生"),
            ft.NavigationBarDestination(icon=ft.Icons.FIRE_EXTINGUISHER, label="滅火"),
            ft.NavigationBarDestination(icon=ft.Icons.QUIZ, label="測驗"),
            ft.NavigationBarDestination(icon=ft.Icons.BUILD, label="工具"),
        ],
        on_change=lambda e: change_tab(e.control.selected_index)
    )
    
    page.navigation_bar = nav_bar
    render_page()
    # 執行加載邏輯（現在是本地快速解析）
    await load_questions()

if __name__ == "__main__":
    ft.app(target=main, assets_dir="assets")