import flet as ft
import asyncio
import os
import random
# 移除 requests，因為 Web 環境下它會導致卡死
from views.escape import escape_view
from views.extinguish import extinguish_view
from views.quiz import quiz_view
from views.tools import tools_view

def main(page: ft.Page):
    page.title = "火災安全衛士 Pro"
    page.window_width = 450
    page.window_height = 1000
    page.padding = 0

# --- 修正後的載入邏輯：專門為 Web 優化 ---
    def load_questions():
        pool = []
        file_name = "questions.txt"
        
        try:
            # 方式 A：Web 環境最穩定的讀取方式 (透過 page.fetch_assets)
            # Flet 會自動從 /assets/questions.txt 下載
            import requests # Web 版 Flet 內建支持小型請求
            
            # 建立指向該檔案的相對 URL
            # 在 GitHub Pages 上，這會指向 https://user.github.io/fire_app/assets/questions.txt
            asset_path = f"assets/{file_name}"
            
            # 如果是在電腦執行，直接讀取
            if os.path.exists(asset_path):
                with open(asset_path, "r", encoding="utf-8") as f:
                    lines = f.readlines()
            else:
                # 在 Web 環境，我們嘗試直接抓取打包後的靜態資源
                # Flet web 會將 assets 放在根目錄下
                response = requests.get(file_name) 
                if response.status_code == 200:
                    response.encoding = 'utf-8'
                    lines = response.text.splitlines()
                else:
                    # 嘗試另一個可能的 Web 路徑
                    response = requests.get(asset_path)
                    response.encoding = 'utf-8'
                    lines = response.text.splitlines()

            for line in lines:
                if not line.strip(): continue # 跳過空白行
                parts = line.strip().split("|")
                if len(parts) >= 2: 
                    pool.append({
                        "q": parts[0], 
                        "a": parts[1:], 
                        "correct_text": parts[1]
                    })
                    
        except Exception as e:
            print(f"Loading error: {e}")
            # 只有當真的讀不到任何東西時，才用這個保底，方便除錯
            pool = [{"q": f"讀取失敗，錯誤：{str(e)}", "a": ["了解"], "correct_text": "了解"}]
            
        return pool

    # 先初始化一個空的，避免讀取過程太久
    raw_pool = load_questions()
    quiz_state = {"score": 0, "current_q": 0, "session_questions": []}

    def reset_quiz():
        quiz_state["score"] = 0
        quiz_state["current_q"] = 0
        quiz_state.pop("current_options", None) 
        if raw_pool:
            # 隨取 10 題，如果題庫不夠就全取
            sample_size = min(len(raw_pool), 10)
            quiz_state["session_questions"] = random.sample(raw_pool, sample_size)

    # --- 其餘邏輯保持不變 ---
    def check_answer(only_update_ui=False):
        if not only_update_ui:
            quiz_state["current_q"] += 1
            quiz_state.pop("current_options", None) 
        render_page()

    def render_page(e=None):
        page.controls.clear()
        idx = nav_bar.selected_index
        titles = ["首頁", "逃生", "滅火", "測驗", "工具"]
        
        page.appbar = ft.AppBar(
            title=ft.Text(titles[idx], weight="bold", color="white"),
            bgcolor="#E63946",
            actions=[ft.IconButton(ft.Icons.HOME, icon_color="white", on_click=lambda _: change_tab(0))]
        )

        if idx == 0:
            page.add(ft.Column([
                ft.Container(
                    height=180, padding=30, 
                    gradient=ft.LinearGradient(colors=["#E63946", "#D62828"]),
                    content=ft.Column([
                        ft.Text("安全教育 Pro", color="white", size=28, weight="bold"), 
                        ft.Text("具體化防災手冊", color="white", size=16)
                    ])
                ),
                ft.Container(
                    padding=20, 
                    content=ft.Column([
                        ft.ListTile(leading=ft.Icon(ft.Icons.RUN_CIRCLE, color="orange"), title=ft.Text("逃生指引"), on_click=lambda _: change_tab(1)),
                        ft.ListTile(leading=ft.Icon(ft.Icons.FIRE_EXTINGUISHER, color="green"), title=ft.Text("滅火教學"), on_click=lambda _: change_tab(2)),
                        ft.ListTile(leading=ft.Icon(ft.Icons.QUIZ, color="blue"), title=ft.Text("小測驗挑戰"), on_click=lambda _: change_tab(3)),
                        ft.ListTile(leading=ft.Icon(ft.Icons.BUILD, color="grey"), title=ft.Text("救生工具箱"), on_click=lambda _: change_tab(4)),
                        ft.Divider(height=20),
                        ft.FilledButton("緊急求助 999", icon=ft.Icons.PHONE, bgcolor="red", on_click=lambda _: page.launch_url("tel:999"), width=400, height=60),
                    ], spacing=10)
                )
            ], scroll=ft.ScrollMode.AUTO))
        
        elif idx == 1: page.add(escape_view())
        elif idx == 2: page.add(extinguish_view())
        elif idx == 3: page.add(quiz_view(quiz_state, check_answer, lambda _: (reset_quiz(), render_page())))
        elif idx == 4: page.add(tools_view(page))
        page.update()

    def change_tab(index):
        nav_bar.selected_index = index
        if index == 3: reset_quiz()
        render_page()

    nav_bar = ft.NavigationBar(
        destinations=[
            ft.NavigationBarDestination(icon=ft.Icons.HOME, label="首頁"),
            ft.NavigationBarDestination(icon=ft.Icons.RUN_CIRCLE, label="逃生"),
            ft.NavigationBarDestination(icon=ft.Icons.FIRE_EXTINGUISHER, label="滅火"),
            ft.NavigationBarDestination(icon=ft.Icons.QUIZ, label="測驗"),
            ft.NavigationBarDestination(icon=ft.Icons.BUILD, label="工具"),
        ],
        on_change=lambda e: change_tab(e.control.selected_index)
    )
    
    page.navigation_bar = nav_bar
    reset_quiz()
    render_page()

if __name__ == "__main__":
    # 這裡的 assets_dir 非常關鍵，它告訴 Flet 去哪裡找 questions.txt
    ft.app(target=main, assets_dir="assets")