import flet as ft
import asyncio
import os
import random
import urllib.request
from views.escape import escape_view
from views.extinguish import extinguish_view
from views.quiz import quiz_view
from views.tools import tools_view

async def main(page: ft.Page):
    page.title = "火災安全衛士 Pro"
    page.window_width = 450
    page.window_height = 1000
    page.padding = 0

    # 初始化資料狀態
    state = {
        "raw_pool": [],
        "quiz": {"score": 0, "current_q": 0, "session_questions": []}
    }

    async def load_questions():
        file_name = "questions.txt"
        # 增加隨機參數 ?v=... 強制讓瀏覽器抓取最新檔案，不使用舊快取
        target_url = f"https://ngankalok.github.io/fire_app/{file_name}?v={random.randint(1, 999999)}"
        lines = []
        
        try:
            # 使用內建的 urllib 抓取，並強制使用 utf-8 解碼
            req = urllib.request.Request(target_url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=5) as response:
                content = response.read().decode('utf-8')
                # 移除特殊的 BOM 字元（有時會出現在 UTF-8 檔案開頭）
                content = content.replace('\ufeff', '')
                lines = content.splitlines()

            parsed_data = []
            for line in lines:
                clean_line = line.strip()
                # 略過空白行
                if not clean_line:
                    continue
                if "|" in clean_line:
                    parts = clean_line.split("|")
                    if len(parts) >= 2:
                        parsed_data.append({
                            "q": parts[0],
                            "a": [p.strip() for p in parts[1:] if p.strip()],
                            "correct_text": parts[1].strip()
                        })
            
            if parsed_data:
                state["raw_pool"] = parsed_data
                print(f"成功載入 {len(parsed_data)} 題題目")
            else:
                state["raw_pool"] = [{"q": "題庫內容解析後為空，請檢查檔案內容", "a": ["了解"], "correct_text": "了解"}]
                
        except Exception as e:
            # 如果是連線問題，嘗試讀取本地 assets (開發環境備案)
            try:
                for path in [file_name, f"assets/{file_name}"]:
                    if os.path.exists(path):
                        with open(path, "r", encoding="utf-8") as f:
                            content = f.read().replace('\ufeff', '')
                            lines = content.splitlines()
                            # ... (後續解析邏輯同上)
            except:
                state["raw_pool"] = [{"q": f"讀取失敗: {str(e)}", "a": ["重試"], "correct_text": "重試"}]
        
        reset_quiz()
        render_page()

    def reset_quiz():
        state["quiz"]["score"] = 0
        state["quiz"]["current_q"] = 0
        state["quiz"].pop("current_options", None) 
        if state["raw_pool"]:
            sample_size = min(len(state["raw_pool"]), 10)
            state["quiz"]["session_questions"] = random.sample(state["raw_pool"], sample_size)

    def check_answer(only_update_ui=False):
        if not only_update_ui:
            state["quiz"]["current_q"] += 1
            state["quiz"].pop("current_options", None) 
        render_page()

    def render_page(e=None):
        page.controls.clear()
        idx = nav_bar.selected_index
        titles = ["首頁", "逃生", "滅火", "測驗", "工具"]
        
        page.appbar = ft.AppBar(
            title=ft.Text(titles[idx], weight="bold", color="white"),
            bgcolor="#E63946",
            actions=[ft.IconButton(ft.Icons.HOME, icon_color="white", on_click=lambda _: change_tab(0))]
        )

        if idx == 0:
            page.add(ft.Column([
                ft.Container(
                    height=180, padding=30, 
                    gradient=ft.LinearGradient(colors=["#E63946", "#D62828"]),
                    content=ft.Column([
                        ft.Text("安全教育 Pro", color="white", size=28, weight="bold"), 
                        ft.Text("具體化防災手冊", color="white", size=16)
                    ])
                ),
                ft.Container(
                    padding=20, 
                    content=ft.Column([
                        ft.ListTile(leading=ft.Icon(ft.Icons.RUN_CIRCLE, color="orange"), title=ft.Text("逃生指引"), on_click=lambda _: change_tab(1)),
                        ft.ListTile(leading=ft.Icon(ft.Icons.FIRE_EXTINGUISHER, color="green"), title=ft.Text("滅火教學"), on_click=lambda _: change_tab(2)),
                        ft.ListTile(leading=ft.Icon(ft.Icons.QUIZ, color="blue"), title=ft.Text("小測驗挑戰"), on_click=lambda _: change_tab(3)),
                        ft.ListTile(leading=ft.Icon(ft.Icons.BUILD, color="grey"), title=ft.Text("救生工具箱"), on_click=lambda _: change_tab(4)),
                        ft.Divider(height=20),
                        ft.FilledButton("緊急求助 999", icon=ft.Icons.PHONE, bgcolor="red", on_click=lambda _: page.launch_url("tel:999"), width=400, height=60),
                    ], spacing=10)
                )
            ], scroll=ft.ScrollMode.AUTO))
        elif idx == 1: page.add(escape_view())
        elif idx == 2: page.add(extinguish_view())
        elif idx == 3: page.add(quiz_view(state["quiz"], check_answer, lambda _: (reset_quiz(), render_page())))
        elif idx == 4: page.add(tools_view(page))
        page.update()

    def change_tab(index):
        nav_bar.selected_index = index
        if index == 3: reset_quiz()
        render_page()

    nav_bar = ft.NavigationBar(
        destinations=[
            ft.NavigationBarDestination(icon=ft.Icons.HOME, label="首頁"),
            ft.NavigationBarDestination(icon=ft.Icons.RUN_CIRCLE, label="逃生"),
            ft.NavigationBarDestination(icon=ft.Icons.FIRE_EXTINGUISHER, label="滅火"),
            ft.NavigationBarDestination(icon=ft.Icons.QUIZ, label="測驗"),
            ft.NavigationBarDestination(icon=ft.Icons.BUILD, label="工具"),
        ],
        on_change=lambda e: change_tab(e.control.selected_index)
    )
    
    page.navigation_bar = nav_bar
    render_page()
    asyncio.create_task(load_questions())

if __name__ == "__main__":
    ft.app(target=main, assets_dir="assets")