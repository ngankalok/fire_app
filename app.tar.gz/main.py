import flet as ft
import asyncio
import os
import random
from views.escape import escape_view
from views.extinguish import extinguish_view
from views.quiz import quiz_view
from views.tools import tools_view

async def main(page: ft.Page):
    page.title = "火災安全衛士 Pro"
    page.window_width = 450
    page.window_height = 1000
    page.padding = 0

    # 建立一個存放題庫的容器
    raw_pool = []
    quiz_state = {"score": 0, "current_q": 0, "session_questions": []}

    # --- 修正後的載入邏輯：使用 async 確保 Web 兼容性 ---
    async def load_questions():
        nonlocal raw_pool
        file_name = "questions.txt"
        lines = []
        
        try:
            # 1. 嘗試從 Web 伺服器抓取 (GitHub Pages 專用)
            # 注意：這裡使用 page.fetch_content
            content = await page.fetch_content(file_name)
            if content:
                lines = content.splitlines()
            else:
                # 2. 備案：嘗試從 assets 資料夾抓取
                content = await page.fetch_content(f"assets/{file_name}")
                if content:
                    lines = content.splitlines()
                else:
                    # 3. 本地電腦執行備案
                    local_path = os.path.join("assets", file_name)
                    if os.path.exists(local_path):
                        with open(local_path, "r", encoding="utf-8") as f:
                            lines = f.readlines()

            new_pool = []
            for line in lines:
                if "|" in line:
                    parts = line.strip().split("|")
                    if len(parts) >= 2:
                        new_pool.append({
                            "q": parts[0], 
                            "a": parts[1:], 
                            "correct_text": parts[1]
                        })
            raw_pool = new_pool
            
        except Exception as e:
            raw_pool = [{"q": f"題庫讀取異常: {str(e)}", "a": ["了解"], "correct_text": "了解"}]
        
        # 載入完畢後，初始化第一次測驗
        reset_quiz()
        render_page()

    def reset_quiz():
        quiz_state["score"] = 0
        quiz_state["current_q"] = 0
        quiz_state.pop("current_options", None) 
        if raw_pool:
            sample_size = min(len(raw_pool), 10)
            quiz_state["session_questions"] = random.sample(raw_pool, sample_size)

    def check_answer(only_update_ui=False):
        if not only_update_ui:
            quiz_state["current_q"] += 1
            quiz_state.pop("current_options", None) 
        render_page()

    def render_page(e=None):
        page.controls.clear()
        idx = nav_bar.selected_index
        titles = ["首頁", "逃生", "滅火", "測驗", "工具"]
        
        page.appbar = ft.AppBar(
            title=ft.Text(titles[idx], weight="bold", color="white"),
            bgcolor="#E63946",
            actions=[ft.IconButton(ft.Icons.HOME, icon_color="white", on_click=lambda _: change_tab(0))]
        )

        if idx == 0:
            page.add(ft.Column([
                ft.Container(
                    height=180, padding=30, 
                    gradient=ft.LinearGradient(colors=["#E63946", "#D62828"]),
                    content=ft.Column([
                        ft.Text("安全教育 Pro", color="white", size=28, weight="bold"), 
                        ft.Text("具體化防災手冊", color="white", size=16)
                    ])
                ),
                ft.Container(
                    padding=20, 
                    content=ft.Column([
                        ft.ListTile(leading=ft.Icon(ft.Icons.RUN_CIRCLE, color="orange"), title=ft.Text("逃生指引"), on_click=lambda _: change_tab(1)),
                        ft.ListTile(leading=ft.Icon(ft.Icons.FIRE_EXTINGUISHER, color="green"), title=ft.Text("滅火教學"), on_click=lambda _: change_tab(2)),
                        ft.ListTile(leading=ft.Icon(ft.Icons.QUIZ, color="blue"), title=ft.Text("小測驗挑戰"), on_click=lambda _: change_tab(3)),
                        ft.ListTile(leading=ft.Icon(ft.Icons.BUILD, color="grey"), title=ft.Text("救生工具箱"), on_click=lambda _: change_tab(4)),
                        ft.Divider(height=20),
                        ft.FilledButton("緊急求助 999", icon=ft.Icons.PHONE, bgcolor="red", on_click=lambda _: page.launch_url("tel:999"), width=400, height=60),
                    ], spacing=10)
                )
            ], scroll=ft.ScrollMode.AUTO))
        
        elif idx == 1: page.add(escape_view())
        elif idx == 2: page.add(extinguish_view())
        elif idx == 3: page.add(quiz_view(quiz_state, check_answer, lambda _: (reset_quiz(), render_page())))
        elif idx == 4: page.add(tools_view(page))
        page.update()

    def change_tab(index):
        nav_bar.selected_index = index
        if index == 3: reset_quiz()
        render_page()

    nav_bar = ft.NavigationBar(
        destinations=[
            ft.NavigationBarDestination(icon=ft.Icons.HOME, label="首頁"),
            ft.NavigationBarDestination(icon=ft.Icons.RUN_CIRCLE, label="逃生"),
            ft.NavigationBarDestination(icon=ft.Icons.FIRE_EXTINGUISHER, label="滅火"),
            ft.NavigationBarDestination(icon=ft.Icons.QUIZ, label="測驗"),
            ft.NavigationBarDestination(icon=ft.Icons.BUILD, label="工具"),
        ],
        on_change=lambda e: change_tab(e.control.selected_index)
    )
    
    page.navigation_bar = nav_bar
    
    # 啟動時先跑初始畫面，然後非同步讀取題庫
    render_page()
    asyncio.create_task(load_questions())

if __name__ == "__main__":
    ft.app(target=main, assets_dir="assets")