import flet as ft
import random

def quiz_view(quiz_state, on_next_q, on_restart):
    # 1. 結束畫面
    if quiz_state["current_q"] >= len(quiz_state["session_questions"]):
        return ft.Container(
            content=ft.Column([
                ft.Icon(ft.Icons.EMOJI_EVENTS, size=80, color="orange"),
                ft.Text("測驗結束！", size=28, weight="bold"),
                ft.Text(f"總分：{quiz_state['score']*10}", size=24, color="blue", weight="bold"),
                ft.FilledButton("再考一次", on_click=on_restart, width=200)
            ], alignment="center", horizontal_alignment="center"),
            expand=True, alignment=ft.Alignment(0, 0)
        )

    # 2. 獲取數據
    q_data = quiz_state["session_questions"][quiz_state["current_q"]]
    correct_ans = q_data["correct_text"]
    
    if "current_options" not in quiz_state or quiz_state.get("last_q_idx") != quiz_state["current_q"]:
        quiz_state["current_options"] = list(q_data["a"])
        random.shuffle(quiz_state["current_options"])
        quiz_state["last_q_idx"] = quiz_state["current_q"]
        quiz_state["selected_option"] = None
        quiz_state["answered"] = False

    def handle_click(option):
        if quiz_state["answered"]: return 
        quiz_state["selected_option"] = option
        quiz_state["answered"] = True
        if option == correct_ans:
            quiz_state["score"] += 1
        on_next_q(only_update_ui=True)

    # 3. 構建選項按鈕
    option_widgets = []
    for opt in quiz_state["current_options"]:
        # 預設樣式：藍框、透明底、黑字
        bg_color = "transparent"
        text_color = "black"
        border_color = "blue"

        # 當已回答時的特殊邏輯
        if quiz_state["answered"]:
            if opt == correct_ans:
                # 正確答案：綠底白字
                bg_color = "green"
                border_color = "green"
                text_color = "white"
            elif opt == quiz_state["selected_option"]:
                # 用戶選錯的那項：橙底白字
                bg_color = "orange"
                border_color = "orange"
                text_color = "white"
            else:
                # 剩下那兩項：保持原樣 (藍框、透明底、黑字)
                pass 

        btn = ft.Container(
            content=ft.Text(opt, size=18, color=text_color, weight="bold"),
            alignment=ft.Alignment(0, 0),
            width=320,
            height=60,
            bgcolor=bg_color,
            border=ft.border.all(2, border_color),
            border_radius=10,
            on_click=lambda e, o=opt: handle_click(o),
        )
        option_widgets.append(btn)

    # 4. 下一題按鈕邏輯
    # 確保按鈕在 answered 為 True 時直接加入 Column，避免 Container 內容更新失敗
    ui_controls = [
        ft.Text(f"進度: {quiz_state['current_q']+1} / 10", size=16, color="grey"),
        ft.Text(f"目前積分: {quiz_state['score']*10}", size=20, color="red", weight="bold"),
        ft.Container(
            content=ft.Text(q_data["q"], size=24, weight="bold", text_align="center"),
            padding=20, height=150, alignment=ft.Alignment(0, 0)
        ),
        ft.Column(option_widgets, horizontal_alignment="center"),
        ft.Container(height=20), # 固定間距
    ]

    if quiz_state["answered"]:
        is_last = quiz_state["current_q"] == len(quiz_state["session_questions"]) - 1
        ui_controls.append(
            ft.FilledButton(
                content=ft.Text("看結果" if is_last else "下一題", size=18),
                width=200, height=50,
                on_click=lambda _: on_next_q(only_update_ui=False)
            )
        )
    else:
        # 未回答時，放一個隱形的相同大小容器，維持版面高度穩定
        ui_controls.append(ft.Container(height=50))

    return ft.Container(
        content=ft.Column(ui_controls, alignment="center", horizontal_alignment="center"),
        expand=True, alignment=ft.Alignment(0, 0)
    )