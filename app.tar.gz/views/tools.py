import flet as ft
import asyncio

def tools_view(page: ft.Page):
    # 狀態文字與進度條
    gps_display = ft.Text("緯度: --\n經度: --", size=18, color="grey", weight="bold")
    addr_display = ft.Text("等待獲取位置...", size=14, color="grey")
    progress_ring = ft.ProgressRing(width=20, height=20, stroke_width=2, visible=False)
    
    # 預設的新港中心座標（模擬結果）
    virtual_lat = "22.29735"
    virtual_lon = "114.16940"

    # 地圖按鈕（初始隱藏）
    map_btn = ft.FilledButton(
        "在地圖中精確標註", 
        icon=ft.Icons.MAP, 
        visible=False,
        bgcolor="blue",
        on_click=lambda _: page.launch_url(f"https://www.google.com/maps/search/?api=1&query={virtual_lat},{virtual_lon}")
    )

    async def simulate_get_location(e):
        # 1. 開始搜尋動畫
        e.control.disabled = True
        progress_ring.visible = True
        addr_display.value = "正在掃描衛星訊號 (GPS)..."
        gps_display.value = "獲取中..."
        gps_display.color = "orange"
        page.update()

        # 2. 模擬延遲
        await asyncio.sleep(1.5)

        # 3. 顯示模擬結果
        gps_display.value = f"緯度: {virtual_lat}° N\n經度: {virtual_lon}° E"
        gps_display.color = "green"
        addr_display.value = "當前精確位置：香港尖沙咀新港中心"
        progress_ring.visible = False
        map_btn.visible = True 
        e.control.disabled = False
        page.update()

    return ft.Column([
        ft.Container(padding=20, content=ft.Column([
            ft.Text("🛠️ 救生工具箱", size=22, weight="bold"),
            
            # 定位卡片
            ft.Container(
                bgcolor="white", padding=20, border_radius=15, border=ft.Border.all(1, "#DDD"),
                content=ft.Column([
                    ft.Row([
                        ft.Icon(ft.Icons.GPS_FIXED, color="blue"),
                        ft.Text("硬體級 GPS 定位", weight="bold"),
                        progress_ring
                    ]),
                    ft.Divider(),
                    gps_display,
                    addr_display,
                    ft.Container(height=10),
                    ft.FilledButton(
                        "獲取當前 GPS 位置", 
                        icon=ft.Icons.MY_LOCATION, 
                        on_click=simulate_get_location,
                        width=320
                    ),
                    map_btn 
                ]) # 回歸預設靠左對齊
            ),
            
            ft.Container(height=10),
            ft.FilledButton("開啟緊急哨聲", icon=ft.Icons.VOLUME_UP, width=400, height=60, bgcolor="orange"),
            ft.FilledButton("開啟 SOS 閃光", icon=ft.Icons.FLASH_ON, width=400, height=60, bgcolor="red"),
        ]))
    ], scroll="auto", expand=True)