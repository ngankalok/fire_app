import flet as ft

def escape_view():
    return ft.Column([
        ft.Container(padding=20, content=ft.Column([
            ft.Text("🏃 逃生必帶物品 (四寶)", size=22, weight="bold"),
            ft.Row([
                ft.Container(content=ft.Column([ft.Icon(ft.Icons.PHONE_ANDROID, size=40, color="blue"), ft.Text("手機")], horizontal_alignment="center"), expand=1, bgcolor="white", padding=10, border_radius=10, border=ft.Border.all(1, "#DDD")),
                ft.Container(content=ft.Column([ft.Icon(ft.Icons.VPN_KEY, size=40, color="amber"), ft.Text("鑰匙")], horizontal_alignment="center"), expand=1, bgcolor="white", padding=10, border_radius=10, border=ft.Border.all(1, "#DDD")),
            ]),
            ft.Row([
                ft.Container(content=ft.Column([ft.Icon(ft.Icons.FACE, size=40, color="green"), ft.Text("口罩")], horizontal_alignment="center"), expand=1, bgcolor="white", padding=10, border_radius=10, border=ft.Border.all(1, "#DDD")),
                ft.Container(content=ft.Column([ft.Icon(ft.Icons.FLASHLIGHT_ON, size=40, color="orange"), ft.Text("電筒")], horizontal_alignment="center"), expand=1, bgcolor="white", padding=10, border_radius=10, border=ft.Border.all(1, "#DDD")),
            ]),
            ft.Divider(height=40),
            ft.Text("🔥 濃煙應對措施", size=22, weight="bold"),
            ft.Container(padding=20, bgcolor="#FFE3E3", border_radius=20, border=ft.Border.all(2, "#E63946"),
                content=ft.Column([
                    ft.ListTile(leading=ft.Icon(ft.Icons.DOOR_BACK_DOOR, color="red"), title=ft.Text("1. 立即關緊門窗")),
                    ft.ListTile(leading=ft.Icon(ft.Icons.TEXTURE, color="blue"), title=ft.Text("2. 濕毛巾塞門縫")),
                    ft.ListTile(leading=ft.Icon(ft.Icons.WAVING_HAND, color="orange"), title=ft.Text("3. 窗邊呼救")),
                    ft.ListTile(leading=ft.Icon(ft.Icons.SOUTH, color="black"), title=ft.Text("4. 保持低姿勢")),
                ]))
        ]))
    ], scroll="auto", expand=True)