import flet as ft

def fire_tool_card(title, suitability, color, icon, label_info, forbidden="", detail="", img_name=""):
    return ft.Container(
        content=ft.Column([
            ft.Row([ft.Icon(icon, color=color, size=30), ft.Text(title, size=22, weight="bold")]),
            ft.Container(content=ft.Image(src=img_name, width=280, height=160, fit="contain"), alignment=ft.Alignment(0, 0)),
            ft.Container(content=ft.Text(f"🎯 適合：{suitability}", size=16, color="white", weight="bold"), bgcolor="green", padding=10, border_radius=8, width=400),
            ft.Container(content=ft.Text(f"⚠️ 標籤：{label_info}", size=16, color="black", weight="bold"), bgcolor="yellow", padding=10, border_radius=8, width=400),
            ft.Container(content=ft.Text(f"🚫 禁用：{forbidden}", size=14, color="white", weight="bold"), bgcolor="red", padding=8, border_radius=8, width=400) if forbidden else ft.Container(),
            ft.Text(detail, size=14, color="black87"),
        ]),
        bgcolor="white", border_radius=15, padding=20, margin=ft.margin.only(bottom=20), border=ft.Border.all(2, color)
    )

def extinguish_view():
    return ft.Column([
        ft.Container(padding=20, content=ft.Column([
            ft.Text("🧯 滅火器實戰指南", size=24, weight="bold"),
            fire_tool_card("消防喉輪", "木材、紙張", "blue", ft.Icons.WATER_DROP, "全紅", forbidden="電器火災", img_name="FireHose.jpg"),
            fire_tool_card("滅火毯", "油鍋、身上起火", "amber", ft.Icons.LAYERS, "黃色包裝", img_name="FireBlanket.jpg"),
            fire_tool_card("二氧化碳", "電器起火", "black", ft.Icons.BOLT, "黑標", detail="不留殘餘", img_name="CO2Extinguisher.jpg"),
            fire_tool_card("泡沫滅火器", "液體、汽油", "orange", ft.Icons.BUBBLE_CHART, "奶油色標", forbidden="電器火災", img_name="FoamExtinguisher.jpg"),
            fire_tool_card("乾粉滅火器", "通用型", "blue-grey", ft.Icons.GRAIN, "藍標", img_name="PowderExtinguisher.jpg"),
            ft.Container(bgcolor="#E8F5E9", padding=20, border_radius=15, content=ft.Text("PASS 使用教學：拔、瞄、壓、掃", size=18, weight="bold", color="green")),
        ]))
    ], scroll="auto", expand=True)